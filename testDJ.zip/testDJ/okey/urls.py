"""testDJ URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import url
from . import views
from django.contrib.auth.views import login,logout,password_reset,password_reset_done,password_reset_complete, password_reset_confirm

urlpatterns = [

    url(r'^home/$',views.home),
    url(r'^check/$',views.check),
    url(r'^login/$',login, {'template_name':'test/login.html'}),
    url(r'^logout/$',logout, {'template_name':'test/logout.html'}),
    url(r'^base/$', views.base),
    url(r'^register/$',views.registration),
    url(r'^profile/$',views.view_profile),
    url(r'^profile/edit/$',views.edit_profile),
    url(r'^profile/password/$',views.change_password),
    url(r'^profile/pwd/reset/$',password_reset,name='password_reset'),
    url(r'^profile/pwd/reset/done/$',password_reset_done, name='password_reset_done'),
    url(r'^profile/pwd/reset/confirm/(?P<uidb64>[0-9A-Za-z]+)-(?P<token>.+)/$',password_reset_confirm,name='password_reset_confirm'),
    url(r'^profile/pwd/reset/complete/$',password_reset_complete,name='password_reset_complete'),

]
from django.shortcuts import render,redirect
from django.contrib.auth.admin import User
from django.contrib.auth.forms import PasswordChangeForm
from okey.forms import RegistrationFORM,User_Update_detail
from django.contrib.auth.decorators import login_required


# Create your views here.

def home(request):
    return render(request,'test/home.html')

def check(request):
    name ="james bond"
    numbers = [1,2,3,42,4,21]
    args={'PersonName':name,'luckyNumber':numbers}
    return render(request,'test/login.html',args)

def base(request):
    return render(request,'base.html')

def login(request):
    return render(request,'test/login.html')

def registration(request):
    if request.method =='POST':
        form = RegistrationFORM(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/okey/login')
    else:
        form = RegistrationFORM()
        args ={'form': form}
        return render(request,'test/register.html',args)
@login_required
def view_profile(request):
    args={'user': request.user}
    return render(request,'test/profile.html',args)
@login_required
def edit_profile(request):

   if request.method =='POST':
       form = User_Update_detail(request.POST, instance=request.user)
       if form.is_valid():
           form.save()
           return redirect('/okey/profile')
   else:
       form = User_Update_detail(instance=request.user)
       args ={'form': form}
       return render(request,'test/edit_profile.html',args)

@login_required
def change_password(request):

    if request.method =='POST':
        form = PasswordChangeForm(data=request.POST, user=request.user)
        if form.is_valid():
            form.save()
            return redirect('/okey/login')
    else:
        form = PasswordChangeForm(user=request.user)
        args ={'form': form}
        return render(request,'test/password_change.html',args)
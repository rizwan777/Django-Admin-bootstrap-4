from django.apps import AppConfig


class OkeyConfig(AppConfig):
    name = 'okey'

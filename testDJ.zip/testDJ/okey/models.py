
'''from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
# Create your models here.
class UserProfile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    description= models.CharField(max_length=100,default='')
    url_photo = models.URLField(default='')
    salary = models.IntegerField(default= 0)

def ConnectProfile(sender,**kwargs):
    if kwargs['created']:
        user=UserProfile.objects.create(user=kwargs['instance'])

post_save.connect(ConnectProfile,sender=User)

'''

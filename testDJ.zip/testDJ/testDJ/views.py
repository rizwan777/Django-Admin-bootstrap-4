from django.shortcuts import redirect

def red_loggin(requests):
    return redirect('/okey/login')
from django.contrib.auth import logout
from django.conf import settings
from django.contrib.auth.models import AnonymousUser
from django.shortcuts import redirect
import re

EXEMPT_URL = [re.compile(settings.LOGIN_URL.lstrip('/'))]
if hasattr(settings,'LOGIN_EXEMPT_URL'):
    EXEMPT_URL += [re.compile(url) for url in settings.LOGIN_EXEMPT_URL]

class RoutingUser:

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        return response

    def process_view(self,request,views_func,views_args,views_kwargs):
        path = request.path_info.lstrip('/')

        if path == '/okey/logout':
            logout(request)

        #url_is_excempt = any(url.match(path) for url in EXEMPT_URL)

        if path == 'app/account/logout':
            logout(request)
        '''
        if request.user.is_authenticated and url_is_excempt:
            return redirect(settings.LOGIN_EXEMPT_URL)

        elif request.user.is_authenticated or url_is_excempt:
            return None
        else:
            return redirect(settings.LOGIN_URL)
        '''
